from kivy.config import Config
Config.set("graphics", "resizable", False)
Config.set("graphics", "width", 800)
Config.set("graphics", "height", 600)

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.modalview import ModalView
from kivy.uix.button import Button
from random import choice
from kivy.clock import Clock

CHARACTER_SET = {
    "easy" : "abcdefghijklmnopqrstuvwxyz",
    "normal" : "abcdefghijklmnopqrstuvwxyzABCDEFGHIFKLMNOPQRSTRVWXYZ",
    "hard" : "abcdefghijklmnopqrstuvwxyzABCDEFGHIFKLMNOPQRSTRVWXYZ0123456789"
}

difficulty = "easy"
sm = ScreenManager()

class Target(Button):
    pass

class TitleScreen(Screen):
    def startButtonClicked(self):
        sm.transition.direction = "left"
        sm.current = "game"
        readyView = ReadyView()
        readyView.open()

class GameScreen(Screen):
    def start(self):
        self.targetExist = [[False for i in range(10)] for j in range(7)]
        Clock.schedule_interval(self.update, 1.0/1.0)

    def update(self, dt):
        indexList = []
        for j in range(7):
            for i in range(10):
                if self.targetExist[j][i] == False:
                    indexList.append([j,i])
                    y, x = choice(indexList)

        target = Target()
        target.pos = (x * 75 + 26, y * 75 + 1)
        target.text = choice(CHARACTER_SET[difficulty])
        self.add_widget(target)
        self.targetExist[y][x] = True

    def returnButtonClicked(self):
        sm.transition.direction = "right"
        sm.current = "title"

class ReadyView(ModalView):
    def yesButtonClicked(self):
        sm.get_screen("game").start()
        self.dismiss()

class TypingApp(App):
    def build(self):
        sm.add_widget(TitleScreen(name="title"))
        sm.add_widget(GameScreen(name="game"))
        return sm

if __name__ == "__main__":
    TypingApp().run()
