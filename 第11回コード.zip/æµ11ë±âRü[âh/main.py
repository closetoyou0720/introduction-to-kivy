from kivy.app import App
from kivy.core.text import LabelBase, DEFAULT_FONT
from kivy.uix.screenmanager import ScreenManager, Screen

LabelBase.register(DEFAULT_FONT, "ipaexg.ttf")
sm = ScreenManager()

class LoginScreen(Screen):
    def loginButtonClicked(self):
        sm.current = "input"

class InputScreen(Screen):
    pass

class ExpenseApp(App):
    def build(self):
        sm.add_widget(LoginScreen(name="login"))
        sm.add_widget(InputScreen(name="input"))
        return sm

if __name__ == '__main__':
    ExpenseApp().run()
