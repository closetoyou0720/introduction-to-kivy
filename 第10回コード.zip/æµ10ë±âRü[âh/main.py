from kivy.app import App
from kivy.core.text import LabelBase, DEFAULT_FONT
from kivy.uix.screenmanager import ScreenManager, Screen

LabelBase.register(DEFAULT_FONT, "ipaexg.ttf")
sm = ScreenManager()

class LoginScreen(Screen):
    pass

class ExpenseApp(App):
    def build(self):
        sm.add_widget(LoginScreen(name="login"))
        return sm

if __name__ == '__main__':
    ExpenseApp().run()
