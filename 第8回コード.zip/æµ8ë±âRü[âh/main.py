from kivy.app import App

class ExpenseApp(App):
    pass

if __name__ == '__main__':
    ExpenseApp().run()
