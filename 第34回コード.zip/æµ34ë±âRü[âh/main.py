from kivy.config import Config
Config.set("graphics", "resizable", False)
Config.set("graphics", "width", 800)
Config.set("graphics", "height", 600)

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.modalview import ModalView
from kivy.uix.button import Button
from random import choice
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.properties import NumericProperty
from kivy.uix.widget import Widget

CHARACTER_SET = {
    "easy" : "abcdefghijklmnopqrstuvwxyz",
    "normal" : "abcdefghijklmnopqrstuvwxyzABCDEFGHIFKLMNOPQRSTRVWXYZ",
    "hard" : "abcdefghijklmnopqrstuvwxyzABCDEFGHIFKLMNOPQRSTRVWXYZ0123456789"
}

DIFFICULTY_DESCTIPTION = {
    "easy" : "only lower-case characters appear",
    "normal" : "mixed-case characters appear",
    "hard" : "mixed-case and numeric characters appear"
}

difficulty = "easy"
sm = ScreenManager()

class Target(Button):
    def __init__(self, posX, posY):
        super().__init__()
        self.posX = posX
        self.posY = posY

class TargetField(Widget):
    pass

class TitleScreen(Screen):
    def startButtonClicked(self):
        self.preStart()
        sm.transition.direction = "left"
        sm.current = "game"
        readyView = ReadyView()
        readyView.open()

    def preStart(self):
        tempGame = sm.get_screen("game")
        tempGame.score = 0

    def difficultyButtonClicked(self):
        sm.transition.direction = "left"
        sm.current = "difficulty"

class GameScreen(Screen):
    targets = []
    score = NumericProperty(0)

    def start(self):
        self.targetField = TargetField()
        self.add_widget(self.targetField)
        self.targetExist = [[False for i in range(10)] for j in range(7)]
        self.targets.clear()
        self.counter = 0
        self.counterLimit = 60

        self.keyboard = Window.request_keyboard(self.keyboardClosed, self)
        self.keyboard.bind(on_key_down=self.keyboardDown)

        Clock.schedule_interval(self.update, 1.0/60.0)

    def end(self):
        self.remove_widget(self.targetField)
        self.targetField = None
        self.keyboard.release()
        Clock.unschedule(self.update)

    def update(self, dt):
        self.counter += 1
        if self.counter >= self.counterLimit:
            indexList = []
            for j in range(7):
                for i in range(10):
                    if self.targetExist[j][i] == False:
                        indexList.append([j,i])
                        y, x = choice(indexList)

            target = Target(x, y)
            target.pos = (x * 75 + 26, y * 75 + 1)
            target.text = choice(CHARACTER_SET[difficulty])
            self.targetField.add_widget(target)
            self.targetExist[y][x] = True
            self.targets.append(target)
            self.counter = 0

        if len(self.targets) >= 20:
            gameOverView = GameOverView()
            gameOverView.ids["final_score"].text = str(self.score)
            gameOverView.open()
            self.end()

    def keyboardClosed(self):
        self.keyboard.unbind(on_key_down=self.keyboardDown)
        self.keyboard = None

    def keyboardDown(self, keyboard, keycode, text, modifiers):
        missFlag = True

        if len(modifiers) == 0:
            if keycode[1] == "shift" or keycode[1] == "rshift":
                return
            elif text.isalnum():
                pass
            else:
                self.score -= 10
                return

        if len(modifiers) == 1:
            if modifiers[0] != "shift":
                return
            else:
                if text.isalpha():
                    text = text.upper()
                else:
                    self.score -= 10
                    return

        if len(modifiers) >= 2:
            return

        for target in self.targets:
            if target.text == text:
                self.targetField.remove_widget(target)
                self.targetExist[target.posY][target.posX] = False
                self.targets.remove(target)
                self.score += 10
                self.counterLimit -= 1
                missFlag = False

        if missFlag:
            self.score -= 10

    def returnButtonClicked(self):
        self.end()
        sm.transition.direction = "right"
        sm.current = "title"

class DifficultyScreen(Screen):
    def returnButtonClicked(self):
        sm.transition.direction = "right"
        sm.current = "title"

    def difficultySelected(self, btn):
        global difficulty
        difficulty = btn.text.lower()
        self.ids["difficulty_description"].text = DIFFICULTY_DESCTIPTION[difficulty]

        for item in ["easy", "normal", "hard"]:
            if item == difficulty:
                self.ids[item].background_normal = "atlas://data/images/defaulttheme/button_pressed"
            else:
                self.ids[item].background_normal = "atlas://data/images/defaulttheme/button"

class ReadyView(ModalView):
    def yesButtonClicked(self):
        sm.get_screen("game").start()
        self.dismiss()

class GameOverView(ModalView):
    def returnButtonClicked(self):
        sm.transition.direction = "right"
        sm.current = "title"
        self.dismiss()

class TypingApp(App):
    def build(self):
        sm.add_widget(TitleScreen(name="title"))
        sm.add_widget(GameScreen(name="game"))
        sm.add_widget(DifficultyScreen(name="difficulty"))
        return sm

if __name__ == "__main__":
    TypingApp().run()
