from kivy.app import App
from kivy.core.text import LabelBase, DEFAULT_FONT

LabelBase.register(DEFAULT_FONT, "ipaexg.ttf")

class ExpenseApp(App):
    pass

if __name__ == '__main__':
    ExpenseApp().run()
