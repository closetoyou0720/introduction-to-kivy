from kivy.config import Config
Config.set("graphics", "resizable", False)
Config.set("graphics", "width", 800)
Config.set("graphics", "height", 600)

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.modalview import ModalView
from kivy.uix.button import Button
from random import randint
from kivy.clock import Clock

sm = ScreenManager()

class Target(Button):
    pass

class TitleScreen(Screen):
    def startButtonClicked(self):
        sm.transition.direction = "left"
        sm.current = "game"
        readyView = ReadyView()
        readyView.open()

class GameScreen(Screen):
    def start(self):
        Clock.schedule_interval(self.update, 1.0/1.0)

    def update(self, dt):
        target = Target()
        target.pos = (randint(0, 9) * 75 + 26, randint(0, 6) * 75 + 1)
        target.text = "a"
        self.add_widget(target)

    def returnButtonClicked(self):
        sm.transition.direction = "right"
        sm.current = "title"

class ReadyView(ModalView):
    def yesButtonClicked(self):
        sm.get_screen("game").start()
        self.dismiss()

class TypingApp(App):
    def build(self):
        sm.add_widget(TitleScreen(name="title"))
        sm.add_widget(GameScreen(name="game"))
        return sm

if __name__ == "__main__":
    TypingApp().run()
