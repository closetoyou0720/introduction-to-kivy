from kivy.config import Config
Config.set("graphics", "resizable", False)
Config.set("graphics", "width", 800)
Config.set("graphics", "height", 600)

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.modalview import ModalView

sm = ScreenManager()

class TitleScreen(Screen):
    def startButtonClicked(self):
        sm.transition.direction = "left"
        sm.current = "game"
        readyView = ReadyView()
        readyView.open()

class GameScreen(Screen):
    def returnButtonClicked(self):
        sm.transition.direction = "right"
        sm.current = "title"

class ReadyView(ModalView):
    def yesButtonClicked(self):
        self.dismiss()

class TypingApp(App):
    def build(self):
        sm.add_widget(TitleScreen(name="title"))
        sm.add_widget(GameScreen(name="game"))
        return sm

if __name__ == "__main__":
    TypingApp().run()
