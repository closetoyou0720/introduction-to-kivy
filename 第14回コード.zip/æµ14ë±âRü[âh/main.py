from kivy.config import Config
Config.set("graphics", "resizable", False)
Config.set("graphics", "width", 640)
Config.set("graphics", "height", 480)

from kivy.app import App
from kivy.core.text import LabelBase, DEFAULT_FONT
from kivy.uix.screenmanager import ScreenManager, Screen

USER_ID = "test"
PASSWORD = "test"
ERROR_MESSAGE = "ログインエラー"

LabelBase.register(DEFAULT_FONT, "ipaexg.ttf")
sm = ScreenManager()

class LoginScreen(Screen):
    def loginButtonClicked(self):
        userID = self.ids["text_userID"].text
        password = self.ids["text_password"].text
        #print("ユーザIDは" + userID)
        #print("パスワードは" + password)
        if userID == USER_ID and password == PASSWORD:
            sm.current = "input"
        else:
            self.ids["error_message"].text = ERROR_MESSAGE

class InputScreen(Screen):
    def clearButtonClicked(self):
        for key in self.ids:
            self.ids[key].text = ""

class ExpenseApp(App):
    def build(self):
        sm.add_widget(LoginScreen(name="login"))
        sm.add_widget(InputScreen(name="input"))
        return sm

if __name__ == '__main__':
    ExpenseApp().run()
